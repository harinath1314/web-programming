class product{
    title:String;
    price:String;
    description:String;
    image:String;
    cat:String;
    
}