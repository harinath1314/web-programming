export class RegDetails {

  constructor(
    public mail: string,
    public mobile: any,
    public password: string
  ) {  }

}